Recursos que utilicé:
Chat GPT: Idea del juego
Youtube: https://youtu.be/WOiM22Z9tHI?si=6YOdpwSTH9iPC2ff -> como poder utilizar la cámara en 3d para mi personaje
Youtube: https://www.youtube.com/shorts/LkcfV-SI414 -> como puedo importar un modelo 3D en mi juego
Youtube: https://www.youtube.com/watch?v=AsnhOs8acXw -> como puedo importar texturas a mi juego y sus configuraciones
Youtube: https://www.youtube.com/watch?v=ZJMt9n0gCqo&list=PLvn1rwek2APGvw2w1xNA0gzBGsXdum714&index=3 -> manejo de las texturas y materiales en Godot
Youtube: https://www.youtube.com/watch?v=87NceKI7V60 -> como utilizar Raycasts en Godot
Ambientcg: https://ambientcg.com/list?type=material%2Catlas%2Cdecal&sort=popular -> sitio web que utilicé para poder conseguir texturas
Sketchfab: https://sketchfab.com/3d-models/among-us-crewmate-rigged-14d6855a088d45a69751fa8d16583c82 -> sitio web donde conseguí el modelo 3D para mi personaje

Aclaración: finalmente me decidí por el momento en no agregar las texturas y el modelo 3D en mi juego debido a que volvia el archivo muy pesado(2 GB aprox), pero no descarto agregarlos en el futuro